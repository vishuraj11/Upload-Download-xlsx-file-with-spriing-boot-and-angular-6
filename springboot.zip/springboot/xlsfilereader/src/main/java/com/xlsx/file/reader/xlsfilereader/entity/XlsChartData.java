/**
 * 
 */
package com.xlsx.file.reader.xlsfilereader.entity;

/**
 * @author Rajendra
 *
 */
public class XlsChartData {

	private long xaxis;
	
	private long yaxis;
	
	public XlsChartData() {
		
	}

	public XlsChartData(long xaxis, long yaxis) {

		this.xaxis = xaxis;
		this.yaxis = yaxis;
	}

	public long getXaxis() {
		return xaxis;
	}

	public void setXaxis(long xaxis) {
		this.xaxis = xaxis;
	}

	public long getYaxis() {
		return yaxis;
	}

	public void setYaxis(long yaxis) {
		this.yaxis = yaxis;
	}
	
	
	
}
