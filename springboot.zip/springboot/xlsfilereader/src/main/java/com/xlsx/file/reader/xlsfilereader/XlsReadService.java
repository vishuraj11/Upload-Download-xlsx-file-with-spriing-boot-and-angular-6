/**
 * 
 */
package com.xlsx.file.reader.xlsfilereader;

import java.io.File;
import java.io.IOException;
import java.util.Iterator;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

/**
 * @author Rajendra
 *
 */
public class XlsReadService {

	/**
	 * @param args
	 */
	
	public static final String SAMPLE_XLSX_FILE_PATH ="E:/HM/poc/doc/xlsfile.xlsx";
	public static void main(String[] args) throws EncryptedDocumentException, InvalidFormatException, IOException {
		
		Workbook workbook= WorkbookFactory.create(new File(SAMPLE_XLSX_FILE_PATH));
		
		System.out.println("Workbook has " + workbook.getNumberOfSheets() + " Sheets : ");
		
		
		Iterator<Sheet> sheetIterator = workbook.sheetIterator();
		
		System.out.println("Retrieving Sheets using Iterator");
		
		while(sheetIterator.hasNext()) {
					
			Sheet sheet = sheetIterator.next();
			
			System.out.println("=>" + sheet.getSheetName());
		}
		
		Sheet sheet= workbook.getSheetAt(0);
		
		DataFormatter dataFormatter = new DataFormatter();
		
		Iterator<Row> rowIterator = sheet.rowIterator();
		
		while(rowIterator.hasNext()) {
			Row row=rowIterator.next();
			
			Iterator<Cell> cellIterator= row.cellIterator();
			
			while(cellIterator.hasNext()) {
				Cell cell= cellIterator.next();
				
				String cellValue=dataFormatter.formatCellValue(cell);
				
				 System.out.print(cellValue + "\t");
				
			}
			
			System.out.println("End");
		}

	}

}
