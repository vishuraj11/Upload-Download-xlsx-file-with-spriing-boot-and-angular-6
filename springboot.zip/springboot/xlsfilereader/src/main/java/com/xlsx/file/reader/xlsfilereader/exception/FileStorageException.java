/**
 * 
 */
package com.xlsx.file.reader.xlsfilereader.exception;

/**
 * @author Raj
 *
 */
public class FileStorageException extends RuntimeException {
    /**
	 * 
	 */
	private static final long serialVersionUID = 974533914927457516L;

	public FileStorageException(String message) {
        super(message);
    }

    public FileStorageException(String message, Throwable cause) {
        super(message, cause);
    }

}
