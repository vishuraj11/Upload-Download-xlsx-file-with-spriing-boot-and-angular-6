/**
 * 
 */
package com.xlsx.file.reader.xlsfilereader.exception;

/**
 * @author Raj
 *
 */

public class MyFileNotFoundException extends RuntimeException {
    /**
	 * 
	 */
	private static final long serialVersionUID = 2638455406223530318L;

	public MyFileNotFoundException(String message) {
        super(message);
    }

    public MyFileNotFoundException(String message, Throwable cause) {
        super(message, cause);
    }

}
