import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { HttpClientModule } from '@angular/common/http'
import { AppComponent } from './app.component';
import { XlsfileUploadComponent } from './xlsfile-upload/xlsfile-upload.component';
import { ReactiveFormsModule } from '@angular/forms';
import { UploadFileService } from './service/upload-file.service';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ChartModule } from '@syncfusion/ej2-angular-charts'; 
import { CategoryService, ColumnSeriesService } from '@syncfusion/ej2-angular-charts';



@NgModule({
  declarations: [
    AppComponent,
    XlsfileUploadComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    HttpClientModule,
    BrowserAnimationsModule,
    ChartModule
  ],
  providers: [
    UploadFileService,
    CategoryService,
    ColumnSeriesService
   ],
  bootstrap: [AppComponent]
})
export class AppModule { }
