import { Injectable } from '@angular/core';
import { HttpClient, HttpEvent } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UploadFileService {

  urlString: string ='http://localhost:8080/api/readfile';



  constructor(private http: HttpClient) { }


  uploadFile(formdata: FormData): Observable<GraphData[]>{

    return this.http.post<any>(this.urlString,formdata);
    
  }
}

export class ResponceData{

 constructor(  public fileName: String,
   public fileDownloadUri : String,
   public fileType: String,
   public size: Number){

 }
}

export class GraphData{

  constructor(public x : Number, public y : Number){

  }
}
