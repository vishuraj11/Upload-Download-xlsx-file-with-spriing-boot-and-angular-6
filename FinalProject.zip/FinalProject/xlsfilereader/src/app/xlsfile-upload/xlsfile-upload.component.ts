import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { UploadFileService, GraphData } from '../service/upload-file.service';


@Component({
  selector: 'app-xlsfile-upload',
  templateUrl: './xlsfile-upload.component.html',
  styleUrls: ['./xlsfile-upload.component.scss']
})
export class XlsfileUploadComponent implements OnInit {

  selectedFiles: FileList;
  currentFileUpload: File;
  public chartData: GraphData [];
  public primaryXAxis: any;
  progress: { percentage: number } = { percentage: 0 };

  registerForm: FormGroup;
  submitted = false;


  constructor(private formBuilder: FormBuilder,private uploadFileService:UploadFileService) { }

  ngOnInit() {
      this.registerForm = this.formBuilder.group({
          fileName: ['', Validators.required],
          file: ['', Validators.required]
      });
  }

  // convenience getter for easy access to form fields
  get f() { return this.registerForm.controls; }

  selectFile(event) {
    this.selectedFiles = event.target.files;
  }

  onSubmit() {
      this.submitted = true;
      this.progress.percentage = 0;
      this.currentFileUpload = this.selectedFiles.item(0);
      let formdata: FormData = new FormData();
 
      formdata.append('file', this.currentFileUpload);

      if (this.registerForm.invalid) {
          return;
      }
  this.uploadFileService.uploadFile(formdata).subscribe(
    (data: GraphData []) => {

      this.chartData = data
  }
    );
   this.primaryXAxis = { valueType: 'Category' };

   
  }
  
}
