package com.xlsx.file.reader.xlsfilereader;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;

import com.xlsx.file.reader.xlsfilereader.utility.FileStorageProperties;

@SpringBootApplication
@EnableConfigurationProperties({
    FileStorageProperties.class
})
public class XlsfilereaderApplication {

	public static void main(String[] args) {
		SpringApplication.run(XlsfilereaderApplication.class, args);
	}

}
