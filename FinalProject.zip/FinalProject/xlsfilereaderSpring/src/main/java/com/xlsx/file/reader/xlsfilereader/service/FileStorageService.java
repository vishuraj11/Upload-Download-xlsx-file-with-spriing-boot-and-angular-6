/**
 * 
 */
package com.xlsx.file.reader.xlsfilereader.service;

import java.io.File;
import java.io.IOException;
import java.util.List;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.xlsx.file.reader.xlsfilereader.utility.GraphValue;

/**
 * @author Raj
 *
 */
@Service
public interface FileStorageService {
	
	public String storeFile(MultipartFile file) throws EncryptedDocumentException, InvalidFormatException;
	
	public Resource loadFileAsResource(String fileName);

	public List<GraphValue> readUploadedXlsFile(File file) throws EncryptedDocumentException, InvalidFormatException, IOException;

}
