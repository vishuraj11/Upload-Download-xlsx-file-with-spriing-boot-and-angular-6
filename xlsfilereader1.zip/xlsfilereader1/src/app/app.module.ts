import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { HttpClientModule } from '@angular/common/http'
import { AppComponent } from './app.component';
import { XlsfileUploadComponent } from './xlsfile-upload/xlsfile-upload.component';
import { ReactiveFormsModule } from '@angular/forms';
import { UploadFileService } from './service/upload-file.service';



@NgModule({
  declarations: [
    AppComponent,
    XlsfileUploadComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    HttpClientModule
  ],
  providers: [UploadFileService],
  bootstrap: [AppComponent]
})
export class AppModule { }
