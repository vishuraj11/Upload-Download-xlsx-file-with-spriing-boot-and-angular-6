import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { UploadFileService } from '../service/upload-file.service';
import { HttpEventType, HttpResponse } from '@angular/common/http';

@Component({
  selector: 'app-xlsfile-upload',
  templateUrl: './xlsfile-upload.component.html',
  styleUrls: ['./xlsfile-upload.component.scss']
})
export class XlsfileUploadComponent implements OnInit {

  selectedFiles: File;
  currentFileUpload: File;
  progress: { percentage: number } = { percentage: 0 };

  registerForm: FormGroup;
  submitted = false;


  constructor(private formBuilder: FormBuilder,private uploadFileService:UploadFileService) { }

  ngOnInit() {
      this.registerForm = this.formBuilder.group({
          fileName: ['', Validators.required],
          file: ['', Validators.required]
      });
  }

  // convenience getter for easy access to form fields
  get f() { return this.registerForm.controls; }

  selectFile(event) {
    this.selectedFiles = event.target.files;
  }

  onSubmit() {
      this.submitted = true;
      this.progress.percentage = 0;
      this.currentFileUpload = this.selectedFiles;
      const formdata: FormData = new FormData();
 
      formdata.append('file', this.currentFileUpload);

      if (this.registerForm.invalid) {
          return;
      }
  this.uploadFileService.uploadFile(formdata).subscribe(event => {
    if (event.type === HttpEventType.UploadProgress) {
      this.progress.percentage = Math.round(100 * event.loaded / event.total);
    } else if (event instanceof HttpResponse) {
      console.log('File is completely uploaded!');
    }
  });
 
  }

}
