import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { XlsfileUploadComponent } from './xlsfile-upload.component';

describe('XlsfileUploadComponent', () => {
  let component: XlsfileUploadComponent;
  let fixture: ComponentFixture<XlsfileUploadComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ XlsfileUploadComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(XlsfileUploadComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
