import { Injectable } from '@angular/core';
import { HttpClient, HttpEvent } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UploadFileService {

  urlString: string ='http://localhost:8080/api/readfile';



  constructor(private http: HttpClient) { }


  uploadFile(formdata: FormData): Observable<HttpEvent<{}>>{

   

    console.log(formdata);

    return this.http.post<any>(this.urlString,formdata);
    
  }
}
